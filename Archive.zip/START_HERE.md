# 🚀 START HERE - Your Betting Chat System

## ⚠️ IMPORTANT: You Must Upgrade Node.js First!

Your current Node.js version (18.16.0) is **too old**. The app won't run without upgrading.

### Run These Commands Now:

```bash
# Install nvm (Node Version Manager)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# IMPORTANT: Close and reopen your terminal after this!
# Then run:

nvm install 20
nvm use 20
nvm alias default 20

# Verify it worked:
node --version
# Should show: v20.x.x
```

## ✅ Once Node.js is Upgraded, Follow These Steps:

### 1. Install Dependencies (1 minute)

```bash
cd betting-chat-system
npm install @supabase/supabase-js
```

### 2. Create Supabase Account (3 minutes)

1. Go to: https://supabase.com
2. Click "Start your project"
3. Sign up (free)
4. Create new project:
   - Name: `betting-chat`
   - Password: (create strong password)
   - Region: (choose closest)
5. Wait 2 minutes for setup

### 3. Get Your Credentials (1 minute)

In Supabase:
1. Click "Settings" (gear icon)
2. Click "API"
3. Copy:
   - **Project URL**
   - **anon public** key

### 4. Configure Environment (1 minute)

```bash
# Copy example file
cp .env.example .env

# Edit .env file
nano .env
```

Paste your credentials:
```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

Save: `Ctrl+X`, then `Y`, then `Enter`

### 5. Set Up Database (2 minutes)

In Supabase:
1. Click "SQL Editor"
2. Click "New Query"
3. Open `QUICK_START.md` and copy the SQL
4. Paste and click "Run"

### 6. Run the App! (30 seconds)

```bash
npm run dev
```

Open: http://localhost:5173

## 🎉 That's It!

### Test It:
1. Register a new account
2. Click a department button
3. Send a message
4. Logout and login as admin to see the chat

## 📚 Documentation Files

- **QUICK_START.md** - 10-minute setup guide
- **SETUP_GUIDE.md** - Complete setup instructions
- **INSTALLATION.md** - Detailed troubleshooting
- **PROJECT_SUMMARY.md** - What you got and how it works
- **README.md** - Project overview

## 🆘 Having Issues?

### "Missing Supabase environment variables"
→ Make sure you created `.env` file with your credentials

### "Failed to create chat"
→ Make sure you ran the SQL scripts in Supabase

### Dev server won't start
→ Make sure Node.js is version 20+: `node --version`

### Still stuck?
→ Check INSTALLATION.md for detailed troubleshooting

## 🎯 What You Got

✅ Complete chat system (better than WhatsApp!)
✅ Login/Register (no phone numbers)
✅ 4 Department buttons
✅ Real-time chat
✅ File & voice message support
✅ Admin dashboard
✅ All source code
✅ Complete documentation

## 💡 Quick Tips

- **Admin Login**: Create admin user with SQL (see QUICK_START.md)
- **Customize**: Edit CSS files in `src/components/`
- **Deploy**: Use Vercel or Netlify (free)
- **Backup**: Supabase auto-backs up daily

## 🚀 Next Steps

1. **Today**: Get it running locally
2. **This Week**: Test with clients
3. **This Month**: Deploy to production
4. **Ongoing**: Customize and improve

---

**Ready?** Start with step 1 above! 👆

**Questions?** Check the documentation files!

**Excited?** You should be - this is way better than WhatsApp! 🎉

