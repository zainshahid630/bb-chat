import { useState, useEffect, useRef } from 'react'
import { messageHelpers, fileHelpers } from '../lib/supabase'
import { playSound, showMessageNotification, clearNotificationsForChat, initNotificationSound } from '../lib/notifications'
import './ChatInterface.css'

export default function ChatInterface({ chat, user, onBack }) {
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [recording, setRecording] = useState(false)
  const [imagePreview, setImagePreview] = useState(null)
  const messagesEndRef = useRef(null)
  const mediaRecorderRef = useRef(null)
  const audioChunksRef = useRef([])
  const fileInputRef = useRef(null)

  const departmentNames = {
    deposit: 'Deposit',
    withdraw: 'Withdraw',
    new_id: 'New User ID',
    complaint: 'Complaint',
  }

  useEffect(() => {
    loadMessages()

    // Clear notifications when opening chat
    clearNotificationsForChat(chat.id)

    // Initialize notification sound on first interaction
    initNotificationSound()

    // Subscribe to new messages
    console.log('🔌 Setting up real-time subscription for chat:', chat.id)
    const messageSubscription = messageHelpers.subscribeToMessages(chat.id, (newMsg, eventType) => {
      console.log('📨 Received message update via real-time:', newMsg, eventType)

      if (eventType === 'update') {
        // Update existing message (for status changes)
        console.log('🔄 Updating message:', newMsg.id)
        setMessages((prev) =>
          prev.map((m) => (m.id === newMsg.id ? newMsg : m))
        )
      } else {
        // New message
        console.log('✨ Adding new message:', newMsg.id)

        // Check if message is from other person (not from current user)
        const isFromOther = newMsg.sender_id !== user.id

        if (isFromOther) {
          // Play sound and show notification
          console.log('🔔 Playing notification sound for new message')
          playSound()

          // Show toast notification
          const senderName = user.is_admin ? (newMsg.users?.username || 'Client') : 'Admin'
          const messagePreview = newMsg.message_type === 'text'
            ? newMsg.content.substring(0, 50) + (newMsg.content.length > 50 ? '...' : '')
            : `${newMsg.message_type === 'image' ? '📷 Image' : newMsg.message_type === 'voice' ? '🎤 Voice' : '📎 File'}`

          showMessageNotification(messagePreview, senderName, chat.id, null)
        }

        setMessages((prev) => {
          // Avoid duplicates
          if (prev.find(m => m.id === newMsg.id)) {
            console.log('⚠️ Duplicate message detected, skipping:', newMsg.id)
            return prev
          }
          return [...prev, newMsg]
        })
      }
      scrollToBottom()
    })

    return () => {
      console.log('🔌 Unsubscribing from chat:', chat.id)
      messageSubscription.unsubscribe()
    }
  }, [chat.id, user.id, user.is_admin])

  const loadMessages = async () => {
    try {
      console.log('Loading messages for chat:', chat.id)
      const msgs = await messageHelpers.getChatMessages(chat.id)
      console.log('Loaded messages:', msgs)
      setMessages(msgs)
      scrollToBottom()

      // Mark messages as read based on who is viewing
      if (user.is_admin) {
        // Admin viewing: mark all client messages as read
        console.log('👁️ Admin viewing chat, marking client messages as read')
        console.log('   Chat ID:', chat.id)
        console.log('   User ID:', user.id)
        await messageHelpers.markMessagesRead(chat.id, user.id)
        console.log('✅ Messages marked as read')
      } else {
        // Client viewing: mark all admin messages as read
        console.log('👁️ Client viewing chat, marking admin messages as read')
        console.log('   Chat ID:', chat.id)
        console.log('   User ID:', user.id)
        await messageHelpers.markMessagesRead(chat.id, user.id)
        console.log('✅ Messages marked as read')
      }
    } catch (err) {
      console.error('Error loading messages:', err)
      // alert('Failed to load messages: ' + err.message)
    }
  }

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }, 100)
  }

  const handleSendMessage = async (e) => {
    e.preventDefault()
    if (!newMessage.trim() || loading) return

    setLoading(true)
    const messageText = newMessage.trim()
    setNewMessage('') // Clear input immediately for better UX

    try {
      console.log('📤 Sending message:', {
        chatId: chat.id,
        userId: user.id,
        senderType: user.is_admin ? 'admin' : 'client',
        content: messageText
      })

      await messageHelpers.sendMessage(
        chat.id,
        user.id,
        user.is_admin ? 'admin' : 'client',
        'text',
        messageText
      )

      console.log('✅ Message sent successfully')
      // Real-time subscription will add it to the UI
      scrollToBottom()
    } catch (err) {
      console.error('❌ Error sending message:', err)
      alert('Failed to send message: ' + err.message)
      setNewMessage(messageText) // Restore message on error
    } finally {
      setLoading(false)
    }
  }

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploading(true)
    try {
      console.log('📎 Uploading file:', file.name)
      const fileUrl = await fileHelpers.uploadFile(file, chat.id)
      const messageType = file.type.startsWith('image/') ? 'image' : 'file'

      console.log('📤 Sending file message:', messageType)
      await messageHelpers.sendMessage(
        chat.id,
        user.id,
        user.is_admin ? 'admin' : 'client',
        messageType,
        file.name,
        fileUrl
      )

      console.log('✅ File sent successfully')
      // Real-time subscription will add it to the UI
      scrollToBottom()
    } catch (err) {
      console.error('❌ Error uploading file:', err)
      alert('Failed to upload file: ' + err.message)
    } finally {
      setUploading(false)
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    }
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data)
      }

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' })
        stream.getTracks().forEach((track) => track.stop())

        setUploading(true)
        try {
          console.log('🎤 Uploading voice message')
          const voiceUrl = await fileHelpers.uploadVoice(audioBlob, chat.id)

          console.log('📤 Sending voice message')
          await messageHelpers.sendMessage(
            chat.id,
            user.id,
            user.is_admin ? 'admin' : 'client',
            'voice',
            'Voice message',
            voiceUrl
          )

          console.log('✅ Voice message sent successfully')
          // Real-time subscription will add it to the UI
          scrollToBottom()
        } catch (err) {
          console.error('❌ Error uploading voice:', err)
          alert('Failed to send voice message: ' + err.message)
        } finally {
          setUploading(false)
        }
      }

      mediaRecorder.start()
      setRecording(true)
    } catch (err) {
      console.error('Error starting recording:', err)
      alert('Could not access microphone')
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop()
      setRecording(false)
    }
  }

  const formatTime = (timestamp) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
  }

  const getMessageStatusIcon = (msg) => {
    // Only show status for messages sent by current user (clients only)
    if (msg.sender_id !== user.id || user.is_admin) return null

    // Default to 'sent' if no status
    const status = msg.status || 'sent'

    switch (status) {
      case 'sent':
        return <span className="status-icon sent">✓</span>
      case 'delivered':
        return <span className="status-icon delivered">✓✓</span>
      case 'read':
        return <span className="status-icon read">✓✓</span>
      default:
        return null
    }
  }

  return (
    <div className="chat-container">
      <div className="chat-header">
        <button className="back-button" onClick={onBack}>
          ← Back
        </button>
        <div className="chat-header-info">
          {user.is_admin ? (
            <>
              <h2>{chat.users?.username || 'Unknown User'}</h2>
              <div className="chat-header-meta">
                <span className="chat-department">{departmentNames[chat.department]}</span>
                <span className="chat-status-dot">•</span>
                <span className="chat-status">{chat.status}</span>
              </div>
            </>
          ) : (
            <>
              <h2>{departmentNames[chat.department]}</h2>
              <span className="chat-status">{chat.status}</span>
            </>
          )}
        </div>
      </div>

      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="empty-state">
            <p>👋 Start the conversation!</p>
            <p className="empty-subtitle">Send a message to get help</p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`message ${msg.sender_type === 'admin' ? 'admin' : 'client'} ${
                msg.sender_id === user.id ? 'own' : 'other'
              }`}
            >
              <div className="message-content" style={{marginTop:"40px"}}>
                {msg.message_type === 'text' && <p>{msg.content}</p>}

                {msg.message_type === 'image' && (
                  <div className="message-image" onClick={() => setImagePreview(msg.file_url)}>
                    <img src={msg.file_url} alt={msg.content} />
                    <p className="image-caption">{msg.content}</p>
                    <div className="image-overlay">
                      <span>🔍 Click to view full size</span>
                    </div>
                  </div>
                )}

                {msg.message_type === 'file' && (
                  <a href={msg.file_url} target="_blank" rel="noopener noreferrer" className="file-link">
                    📎 {msg.content}
                  </a>
                )}

                {msg.message_type === 'voice' && (
                  <audio controls src={msg.file_url} className="voice-player" />
                )}
              </div>
              <div className="message-footer">
                <span className="message-time">{formatTime(msg.created_at)}</span>
                {getMessageStatusIcon(msg)}
              </div>
            </div>
          ))
        )}



        <div ref={messagesEndRef} />
      </div>

      <form className="message-input-container" onSubmit={handleSendMessage}>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          style={{ display: 'none' }}
          accept="image/*,.pdf,.doc,.docx"
        />
        
        <button
          type="button"
          className="icon-button"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          title="Upload file or image"
        >
          📎
        </button>

        <button
          type="button"
          className={`icon-button ${recording ? 'recording' : ''}`}
          onClick={recording ? stopRecording : startRecording}
          disabled={uploading}
          title={recording ? 'Stop recording' : 'Record voice message'}
        >
          🎤
        </button>

        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder={uploading ? 'Uploading...' : recording ? 'Recording...' : 'Type a message...'}
          disabled={loading || uploading || recording}
          className="message-input"
        />

        <button
          type="submit"
          className="send-button"
          disabled={!newMessage.trim() || loading || uploading}
        >
          Send
        </button>
      </form>

      {/* Image Preview Modal */}
      {imagePreview && (
        <div className="image-preview-modal" onClick={() => setImagePreview(null)}>
          <div className="image-preview-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-preview" onClick={() => setImagePreview(null)}>
              ✕
            </button>
            <img src={imagePreview} alt="Full size preview" />
            <div className="preview-actions">
              <a href={imagePreview} download target="_blank" rel="noopener noreferrer" className="download-button">
                ⬇️ Download
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

