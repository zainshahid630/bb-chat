import { useState, useEffect, useRef } from 'react'
import { chatHelpers, supabase } from '../lib/supabase'
import ChatInterface from './ChatInterface'
import UserManagement from './UserManagement'
import { playSound, showMessageNotification, clearNotificationsForChat, initNotificationSound } from '../lib/notifications'
import './AdminPanel.css'

export default function AdminPanel({ user, onLogout }) {
  const [chats, setChats] = useState([])
  const [selectedChat, setSelectedChat] = useState(null)
  const [filter, setFilter] = useState('all')
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('chats') // 'chats' or 'users'
  const subscriptionsRef = useRef(new Map())

  const departmentNames = {
    deposit: 'Deposit',
    withdraw: 'Withdraw',
    new_id: 'New User ID',
    complaint: 'Complaint',
  }

  const departmentIcons = {
    deposit: '💰',
    withdraw: '💸',
    new_id: '🆔',
    complaint: '⚠️',
  }

  useEffect(() => {
    loadChats()

    // Initialize notification sound
    initNotificationSound()

    // OPTIMIZED: Use real-time updates instead of polling
    // Subscribe to chat table changes (new chats, status changes)
    const chatSubscription = supabase
      .channel('admin-chats')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'chats',
        },
        (payload) => {
          console.log('🔄 Chat table changed:', payload)
          // Reload chats when any chat is created/updated/deleted
          loadChats()
        }
      )
      .subscribe()

    return () => {
      chatSubscription.unsubscribe()
      // Cleanup all subscriptions
      subscriptionsRef.current.forEach(sub => sub.unsubscribe())
      subscriptionsRef.current.clear()
    }
  }, [])

  // OPTIMIZED: Single subscription to ALL messages instead of per-chat subscriptions
  // This reduces 100 WebSocket channels to just 1!
  useEffect(() => {
    if (chats.length === 0) return

    // Subscribe to ALL messages in one channel
    const messagesSubscription = supabase
      .channel('admin-all-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
        },
        (payload) => {
          const newMsg = payload.new

          // Only show notification if:
          // 1. It's from a client (not admin)
          // 2. The chat is not currently open
          if (newMsg.sender_type === 'client' &&
              (!selectedChat || selectedChat.id !== newMsg.chat_id)) {

            console.log('🔔 New message in background chat:', newMsg.chat_id)

            // Find the chat for this message
            const chat = chats.find(c => c.id === newMsg.chat_id)

            if (chat) {
              // Play sound
              playSound()

              // Show toast notification
              const username = chat.users?.username || 'Client'
              const messagePreview = newMsg.message_type === 'text'
                ? newMsg.content.substring(0, 50) + (newMsg.content.length > 50 ? '...' : '')
                : `${newMsg.message_type === 'image' ? '📷 Image' : newMsg.message_type === 'voice' ? '🎤 Voice' : '📎 File'}`

              showMessageNotification(messagePreview, username, chat.id, (chatId) => {
                // When notification is clicked, open the chat
                const chatToOpen = chats.find(c => c.id === chatId)
                if (chatToOpen) {
                  setSelectedChat(chatToOpen)
                  clearNotificationsForChat(chatId)
                }
              })
            }

            // Refresh chat list to update unread count
            loadChats()
          }
        }
      )
      .subscribe()

    // Store subscription for cleanup
    subscriptionsRef.current.set('all-messages', messagesSubscription)

    return () => {
      messagesSubscription.unsubscribe()
      subscriptionsRef.current.delete('all-messages')
    }
  }, [chats, selectedChat])

  const loadChats = async () => {
    try {
      const allChats = await chatHelpers.getAllChats()
      setChats(allChats)
      console.log(allChats,'allChats')
    } catch (err) {
      console.error('Error loading chats:', err)
    } finally {
      setLoading(false)
    }
  }

  const filteredChats = chats.filter((chat) => {
    if (filter === 'all') return true
    if (filter === 'open') return chat.status === 'open'
    if (filter === 'closed') return chat.status === 'closed'
    return chat.department === filter
  })

  // Calculate total unread messages (moved before return for use in JSX)
  const totalUnread = chats.reduce((sum, chat) => sum + (chat.unread_count || 0), 0)

  // Calculate unread by department
  const unreadByDept = {
    deposit: chats.filter(c => c.department === 'deposit').reduce((sum, c) => sum + (c.unread_count || 0), 0),
    withdraw: chats.filter(c => c.department === 'withdraw').reduce((sum, c) => sum + (c.unread_count || 0), 0),
    new_id: chats.filter(c => c.department === 'new_id').reduce((sum, c) => sum + (c.unread_count || 0), 0),
    complaint: chats.filter(c => c.department === 'complaint').reduce((sum, c) => sum + (c.unread_count || 0), 0),
  }

  const getLastMessage = (chat) => {
    if (!chat.messages || chat.messages.length === 0) {
      return 'No messages yet'
    }
    const lastMsg = chat.messages[chat.messages.length - 1]
    if (lastMsg.message_type === 'text') {
      return lastMsg.content.substring(0, 50) + (lastMsg.content.length > 50 ? '...' : '')
    }
    return `${lastMsg.message_type === 'image' ? '📷' : lastMsg.message_type === 'voice' ? '🎤' : '📎'} ${lastMsg.message_type}`
  }

  const formatDate = (timestamp) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diff = now - date
    
    if (diff < 60000) return 'Just now'
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
    return date.toLocaleDateString()
  }

  const handleCloseChat = async (chatId) => {
    try {
      await chatHelpers.updateChatStatus(chatId, 'closed')
      loadChats()
      setSelectedChat(null)
    } catch (err) {
      console.error('Error closing chat:', err)
      alert('Failed to close chat')
    }
  }

  if (selectedChat) {
    // Clear notifications when chat is opened
    clearNotificationsForChat(selectedChat.id)

    return (
      // <div className="admin-chat-view">
      <>        <ChatInterface
          chat={selectedChat}
          user={user}
          onBack={() => {
            setSelectedChat(null)
            loadChats()
          }}
        />
        <div className="chat-actions">
          <button
            className="close-chat-button"
            onClick={() => handleCloseChat(selectedChat.id)}
          >
            Close Chat
          </button>
        </div>
        </>

      // </div>
    )
  }

  return (
    <div className="admin-container">
      <div className="admin-header">
        <div>
          <h1>Admin Panel 👨‍💼</h1>
          <p>Manage all customer conversations and users</p>
        </div>
        <button className="logout-button" onClick={onLogout}>
          Logout
        </button>
      </div>

      <div className="admin-tabs">
        <button
          className={`tab-button ${activeTab === 'chats' ? 'active' : ''}`}
          onClick={() => setActiveTab('chats')}
        >
          💬 Chats
          {totalUnread > 0 && (
            <span className="tab-unread-badge">{totalUnread}</span>
          )}
        </button>
        <button
          className={`tab-button ${activeTab === 'users' ? 'active' : ''}`}
          onClick={() => setActiveTab('users')}
        >
          👥 Users
        </button>
      </div>

      {activeTab === 'users' ? (
        <UserManagement currentUser={user} />
      ) : (
        <>
          <div className="admin-filters">
        <button
          className={`filter-button ${filter === 'all' ? 'active' : ''}`}
          onClick={() => setFilter('all')}
        >
          All ({chats.length})
          {totalUnread > 0 && <span className="unread-badge">{totalUnread}</span>}
        </button>
        <button
          className={`filter-button ${filter === 'open' ? 'active' : ''}`}
          onClick={() => setFilter('open')}
        >
          Open ({chats.filter((c) => c.status === 'open').length})
        </button>
        <button
          className={`filter-button ${filter === 'deposit' ? 'active' : ''}`}
          onClick={() => setFilter('deposit')}
        >
          💰 Deposit
          {unreadByDept.deposit > 0 && <span className="unread-badge">{unreadByDept.deposit}</span>}
        </button>
        <button
          className={`filter-button ${filter === 'withdraw' ? 'active' : ''}`}
          onClick={() => setFilter('withdraw')}
        >
          💸 Withdraw
          {unreadByDept.withdraw > 0 && <span className="unread-badge">{unreadByDept.withdraw}</span>}
        </button>
        <button
          className={`filter-button ${filter === 'new_id' ? 'active' : ''}`}
          onClick={() => setFilter('new_id')}
        >
          🆔 New ID
          {unreadByDept.new_id > 0 && <span className="unread-badge">{unreadByDept.new_id}</span>}
        </button>
        <button
          className={`filter-button ${filter === 'complaint' ? 'active' : ''}`}
          onClick={() => setFilter('complaint')}
        >
          ⚠️ Complaint
          {unreadByDept.complaint > 0 && <span className="unread-badge">{unreadByDept.complaint}</span>}
        </button>
      </div>

      <div className="chats-list">
        {loading ? (
          <div className="loading-state">Loading chats...</div>
        ) : filteredChats.length === 0 ? (
          <div className="empty-state">
            <p>📭 No chats found</p>
            <p className="empty-subtitle">Chats will appear here when customers contact you</p>
          </div>
        ) : (
          filteredChats.map((chat) => (
            <div
              key={chat.id}
              className={`chat-item ${chat.status === 'open' ? 'open' : 'closed'} ${chat.unread_count > 0 ? 'has-unread' : ''}`}
              onClick={() => setSelectedChat(chat)}
            >
              <div className="chat-item-icon">
                {departmentIcons[chat.department]}
                {chat.unread_count > 0 && (
                  <span className="chat-unread-badge">{chat.unread_count}</span>
                )}
              </div>
              <div className="chat-item-content">
                <div className="chat-item-header">
                  <span className="chat-item-user">
                    {chat.users?.username || 'Unknown User'}
                  </span>
                  <span className="chat-item-time">
                    {formatDate(chat.updated_at)}
                  </span>
                </div>
                <div className="chat-item-department">
                  {departmentNames[chat.department]}
                </div>
                <div className="chat-item-preview">
                  {getLastMessage(chat)}
                </div>
              </div>
              <div className={`chat-item-status ${chat.status}`}>
                {chat.status}
              </div>
            </div>
          ))
        )}
      </div>
        </>
      )}
    </div>
  )
}

