import { useState, useEffect } from 'react'
import { authHelpers, chatHelpers } from './lib/supabase'
import Login from './components/Login'
import DepartmentSelect from './components/DepartmentSelect'
import ChatInterface from './components/ChatInterface'
import AdminPanel from './components/AdminPanel'
import './App.css'

function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [currentChat, setCurrentChat] = useState(null)

  useEffect(() => {
    checkUser()
  }, [])

  const checkUser = async () => {
    try {
      const currentUser = await authHelpers.getCurrentUser()
      setUser(currentUser)

      // FIXED: Auto-restore last active chat for non-admin users
      if (currentUser && !currentUser.is_admin) {
        await restoreLastChat(currentUser.id)
      }
    } catch (err) {
      console.error('Error checking user:', err)
    } finally {
      setLoading(false)
    }
  }

  const restoreLastChat = async (userId) => {
    try {
      // Get user's most recent open chat
      const chats = await chatHelpers.getUserChats(userId)
      const lastOpenChat = chats.find(chat => chat.status === 'open')

      if (lastOpenChat) {
        console.log('Restoring last active chat:', lastOpenChat)
        setCurrentChat(lastOpenChat)
      }
    } catch (err) {
      console.error('Error restoring chat:', err)
      // Don't throw - just let user select department
    }
  }

  const handleLogin = async (userData) => {
    setUser(userData)

    // FIXED: Auto-restore last active chat after login
    if (userData && !userData.is_admin) {
      await restoreLastChat(userData.id)
    }
  }

  const handleLogout = async () => {
    try {
      await authHelpers.signOut()
      setUser(null)
      setCurrentChat(null)
    } catch (err) {
      console.error('Error logging out:', err)
    }
  }

  const handleSelectDepartment = (chat) => {
    setCurrentChat(chat)
  }

  const handleBackToDepartments = () => {
    setCurrentChat(null)
  }

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="spinner"></div>
        <p>Loading...</p>
      </div>
    )
  }

  // Not logged in - show login
  if (!user) {
    return <Login onLogin={handleLogin} />
  }

  // Admin user - show admin panel
  if (user.is_admin) {
    return <AdminPanel user={user} onLogout={handleLogout} />
  }

  // Regular user with active chat - show chat interface
  if (currentChat) {
    return (
      <ChatInterface
        chat={currentChat}
        user={user}
        onBack={handleBackToDepartments}
      />
    )
  }

  // Regular user - show department selection
  return (
    <DepartmentSelect
      user={user}
      onSelectDepartment={handleSelectDepartment}
      onLogout={handleLogout}
    />
  )
}

export default App
